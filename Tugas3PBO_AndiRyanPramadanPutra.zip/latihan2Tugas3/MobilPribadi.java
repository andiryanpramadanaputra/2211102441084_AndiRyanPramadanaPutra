import greenfoot.*;

public class MobilPribadi extends Mobil {
    public void nyalakanTape() {
        // Implementasi untuk menyalakan tape pada mobil pribadi
    }
    
    public void nyalakanTV() {
        // Implementasi untuk menyalakan TV pada mobil pribadi
    }
    
    public void nyalakanAC() {
        // Implementasi untuk menyalakan AC pada mobil pribadi
    }
    
    public void nyalakanMesin() {
        // Implementasi untuk menyalakan mesin pada mobil pribadi
    }
    
    public void matikanMesin() {
        // Implementasi untuk mematikan mesin pada mobil pribadi
    }
    
    public void tambahGerigi() {
        // Implementasi untuk menambah gerigi pada mobil pribadi
    }
    
    public void turunkanGerigi() {
        // Implementasi untuk menurunkan gerigi pasa mobil pribadi
    }
    
    public void tekanGas() {
        // Implementasi untuk menekan gas pada mobil pribadi
    }
    
    public void tekanRem() {
        // Implementasi untuk menekan rem pada mobil pribadi
    }
    
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}