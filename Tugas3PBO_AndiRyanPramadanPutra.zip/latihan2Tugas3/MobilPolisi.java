import greenfoot.*;

public class MobilPolisi extends MobilNegara {
    public void nyalakanSirine() {
        // Implementasi untuk menyalakan sirine pada mobil polisi
    }
    
    public void matikanSirine() {
        // Implementasi untuk mematikan sirine pada mobil polisi
    }
    
    public void gantiSirine(int jenis) {
        // Implementasi untuk mengganti jenis sirine pada mobil polisi
    }
    
    public void nyalakanRadioHT() {
        // Implementasi untuk menyalakan radio HT pada mobil polisi
    }
    
    public void matikanRadioHT() {
        // Implementasi untuk mematikan radio HT pada mobil polisi
    }
    
    public void nyalakanTape() {
        // Implementasi untuk menyalakan tape pada mobil polisi
    }
    
    public void nyalakanTV() {
        // Implementasi untuk menyalakan tv pada mobil polisi
    }
    
    public void nyalakanMesin() {
        // Implementasi untuk menylakan mesin pada mobil polisi
    }
    
    public void matikanMesin() {
        // Implementasi untuk mematikan mesin pada mobil polisi
    }
    
    public void nyalakanAC() {
        // Implementasi untuk menyalakan ac pada mobil polisi
    }
    
    public void tekanGas() {
        // Implementasi untuk menekan gas pada mobil polisi
    }
    
    public void tekanRem() {
        // Implementasi untuk menekan rem pada mobil polisi
    }
    
    public void tambahGerigi() {
        // Implementasi untuk menambah gerigi pada mobil polisi
    }
    
    public void turunkanGerigi() {
        // implementasi untuk menurunkan gerigi pada mobil polisi
    }
    
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}