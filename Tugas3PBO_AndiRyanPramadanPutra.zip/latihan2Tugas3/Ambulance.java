import greenfoot.*;

public class Ambulance extends MobilNegara {
    public void nyalakanTape() {
        // Implementasi untuk menyalakan tape pada ambulance
    }
    
    public void nyalakanTV() {
        // Implementasi untuk menyalakan TV pada ambulance
    }
    
    public void nyalakanAC() {
        // Implementasi untuk menyalakan AC pada ambulance
    }
    
    public void nyalakanSirine() {
        // Implementasi untuk menyalakan sirine pada ambulance
    }
    
    public void matikanSirine() {
        // Implementasi untuk mematikan sirine pada ambulance
    }
    
    public void gantiSirine(int jenis) {
        // Implementasi untuk mengganti jenis sirine pada ambulance
    }
    
    public void TekanGas(int jenis) {
        // Implementasi untuk menekan gas pada ambulance
    }
    
    public void TekanRem(int jenis) {
        // Implementasi untuk menekan rem pada ambulance
    }
    
    public void TambahGerigi() {
        // Implementasi untuk menambah gerigi pada ambulance
    }
    
    public void TurunkanGerigi() {
        // Implementasi untuk menurunkan gerigi pada ambulance
    }
    
    public void NyalakanMesin() {
        // Implementasi untuk menyalakan mesin pada ambulance 
    }
    
    public void MatikanMesin() {
        // Implementasi untuk mematikan mesin pada ambulance
    }
    
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}