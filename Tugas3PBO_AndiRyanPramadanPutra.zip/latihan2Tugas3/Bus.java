import greenfoot.*;

public class Bus extends MobilPribadi {
    public void nyalakanTape() {
        // Implementasi untuk menyalakan tape pada bus
    }
    
    public void nyalakanTV() {
        // Implementasi untuk menyalakan TV pada bus
    }
    
    public void nyalakanAC() {
        // Implementasi untuk menyalakan AC pada bus
    }
    
    public void tekanGas() {
        // Implementasi untuk menekan gas pada bus
    }
    
    public void tekanRem() {
        // Implementasi untuk menekan rem pada bus
    }
    
    public void nyalakanMesin() {
        // Implementasi untuk menyalakan mesin pada bus
    }
    
    public void matikanMesin() {
        // Implementasi untuk mematikan mesin pada bus
    }
    
    public void tambahGerigi() {
        // Implementasi untuk menambah gerigi pada bus
    }
    
    public void turunkanGerigi() {
        // Implementasi untuk menurunkan gerigi pada bus
    }
    
    public void tambahPenumpang() {
        // implementasi untuk menambah penumppang pada bus
    }
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}